# Archivos de prueba — Dubbing Clip Checker

Serie ficticia: **Dark Echoes** (serie austriaca doblada al español)

## Archivos

| Archivo | Descripción |
|---------|-------------|
| `test_PLDL.xlsx` | Dialog List del cliente (35 entradas) |
| `test_DUB_SCRIPT.xlsx` | Guion en español (32 entradas + 1 extra) |
| `test_ProTools_SessionInfo.txt` | Session Info de Pro Tools (24fps, 48kHz) |
| `test_KNP.xlsx` | Key Names & Phrases (11 términos) |

## Casos de prueba cubiertos

### Parsing y normalización
- **Apóstrofe**: `ZACK'S MOTHER` en PLDL → `ZACKS_MOTHER_LauraTorres` en PT
- **Diéresis**: `MÜLLER` en PLDL → `MULLER_OscarFlores` en PT (track `MALE_SECONDARY_CHARACTERS1`)
- **Nombres compuestos**: `NICK BRADLEY` → track `NICK_BRADLEY_JuanPerez`, `VANESSA BRADLEY` → `VANESSA_BRADLEY_AnaGomez`
- **Drop frame**: Dos entradas con TC en formato `;` (00:03:10;05, 00:03:14;00)
- **Encoding**: Archivo PT en formato latin-1 (estándar Mac)

### Tracks y matching
- **Stems de sesión completa**: `DIA_STEM`, `PM_OV`, `LAS_MIX` — clips de 42 min que deben ser filtrados
- **FUTZ/phone**: Elena Voss clip de teléfono en track `FUTZ PHONE`
- **Personaje en track ajeno**: `INSPECTOR GRAF` tiene clips en el track de `NICK BRADLEY` (como HARAMOL en GIANNINA)
- **Tracks SEC_H / SEC_M**: `ZACK'S MOTHER` en SEC_H, `FEMALE DOCTOR` en SEC_M
- **Track MALE_SECONDARY_CHARACTERS1**: `MÜLLER` clips aquí (sin track propio)
- **Tracks auxiliares**: `ALT`, `original`, `para edit`, `AMBIENTE` — todos con clips válidos

### Fuentes excluibles
- **WALLA**: 1 entrada (tag INAUDIBLE)
- **MAIN TITLE**: 1 entrada (tag MAIN TITLE)
- **GRAPHICS INSERTS**: 1 entrada
- **PRINCIPAL PHOTOGRAPHY**: 1 entrada
- **AD**: 1 entrada
- **NARRATOR**: 2 entradas (para probar exclusión manual de personaje)

### Tags edge case
- Entrada con tag `MAIN TITLE IN DIALOGUE,CONTEXT` → NO debe ser excluida (es diálogo real)

### Reacciones
- 4 entradas tipo `[REACTION]` y `[REAC]` → excluibles con "Excluir reacciones"

### Faltantes intencionados
- `ELENA VOSS` en 00:02:40:00 — "This is the key to everything" — **NO hay clip en PT**
- `MARCO LÓPEZ` en 00:02:44:00 — "We need to act now" — **NO hay clip en PT**

### Cruce PLDL ↔ Dub Script
- TCs idénticos entre PLDL y DUB (estilo Salish)
- TRANSCRIPTION del DUB coincide con DIALOGUE del PLDL
- DUB tiene 1 entrada extra (jadeo de Elena en 00:04:05)

### KNP
- **Word boundary**: Término `Vo` (2 letras) — no debe matchear dentro de "Voss"
- **Término largo**: `Inspector Graf`, `Black Sun` (multi-palabra)
- **Traducción**: `Black Sun` → `Sol Negro` (con nota de traducción)
- **Pronunciación**: `Müller` con nota de no hispanizar
- **Título**: `Dark Echoes` marcado como no traducible
- **Frase clave**: `the coin` / `la moneda` — término que aparece en diálogo real

## Resultados esperados

Al cotejar con config default (Excluir no-diálogo ✓, Excluir reacciones ✗):
- **Total**: ~30 entradas (35 - 5 non-dialog)
- **Grabados**: ~28
- **Faltantes**: 2 (Elena 00:02:40 + Marco 00:02:44)

Con "Excluir reacciones" activado:
- **Total**: ~26
- **Faltantes**: 2 (mismos)

Con NARRATOR excluido vía 👤 Personajes:
- NARRATOR aparece como EXCLUIDO (no suma a faltantes)
